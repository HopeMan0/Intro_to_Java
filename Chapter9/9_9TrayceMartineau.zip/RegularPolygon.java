public class RegularPolygon {
		
		//Sides of the polygon
		private int n;
		//length of the side
		private double side;
		//x coordinate
		private double x;
		//y coordinate
		private double y;
		
	RegularPolygon(){
		n = 3;
		side = 1;
		x = 0;
		y = 0;
	}
	RegularPolygon(int newN, double newSide){
		n = newN;
		side = newSide;
		x = 0;
		y = 0;
	}
	RegularPolygon(int newN, double newSide, double newX, double newY){
		n = newN;
		side = newSide;
		x = newX;
		y = newY;
	}
	
	public void setN(int newN) {
		n = newN;
	}
	public void setSide(double newSide){
		side = newSide;
	}
	public void setX(int newX){
		x = newX;
	}
	public void setY(int newY){
		y = newY;
	}
	
	public int getN(){
		return n;
	}
	public double getSide(){
		return side;
	}
	public double getX(){
		return x;
	}
	public double getY(){
		return y;
	}
	
	
	public double getPerimeter(){
		return n * side;
	}
	public double getArea(){
		return (n * Math.pow(side, 2)) / (4 * Math.tan(Math.PI /n));
	}
}