class Exercise9_9 {
	public static void main(String[] args) {
		RegularPolygon regularPolygon1 = new RegularPolygon();
		RegularPolygon regularPolygon2 = new RegularPolygon(6, 4);
		RegularPolygon regularPolygon3 = new RegularPolygon(10, 4, 5.6, 7.8);
		
		System.out.printf("Object #1 Perimeter: " + regularPolygon1.getPerimeter() + " and Area: " + regularPolygon1.getArea());
		
		
		System.out.printf("Object #2 Perimeter: " + regularPolygon2.getPerimeter() + " and Area: " + regularPolygon2.getArea());
		
		
		System.out.printf("Object #1 Perimeter: " + regularPolygon3.getPerimeter() + " and Area: " + regularPolygon3.getArea());
	}
}